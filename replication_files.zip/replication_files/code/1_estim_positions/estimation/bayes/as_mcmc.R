######################################################################
## Convert Estimation Outputs to MCMC                               ##
## ---------------------------------------------------------------- ##
## ADW: Presidents, Policy Compromise and Legislative Success. JOP. ##
## June 2016                                                        ##
## Implemented in R 3.2.3 "Wooden Christmas-Tree"                   ##
######################################################################


arg.nb.b.80.mcmc <- as.mcmc.list(lapply(arg.nb.b.80, as.mcmc))
bra.nb.b.80.mcmc <- as.mcmc.list(lapply(bra.nb.b.80, as.mcmc))
chi.nb.b.80.mcmc <- as.mcmc.list(lapply(chi.nb.b.80, as.mcmc))
col.nb.b.80.mcmc <- as.mcmc.list(lapply(col.nb.b.80, as.mcmc))
cri.nb.b.80.mcmc <- as.mcmc.list(lapply(cri.nb.b.80, as.mcmc))
ecu.nb.b.80.mcmc <- as.mcmc.list(lapply(ecu.nb.b.80, as.mcmc))
gtm.nb.b.80.mcmc <- as.mcmc.list(lapply(gtm.nb.b.80, as.mcmc))
mex.nb.b.80.mcmc <- as.mcmc.list(lapply(mex.nb.b.80, as.mcmc))
per.nb.b.80.mcmc <- as.mcmc.list(lapply(per.nb.b.80, as.mcmc))
pry.nb.b.80.mcmc <- as.mcmc.list(lapply(pry.nb.b.80, as.mcmc))
slv.nb.b.80.mcmc <- as.mcmc.list(lapply(slv.nb.b.80, as.mcmc))
ury.nb.b.80.mcmc <- as.mcmc.list(lapply(ury.nb.b.80, as.mcmc))
ven.nb.b.80.mcmc <- as.mcmc.list(lapply(ven.nb.b.80, as.mcmc))





